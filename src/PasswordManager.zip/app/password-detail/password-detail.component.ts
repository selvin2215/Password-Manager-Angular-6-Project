import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { IPassDetails } from '../common/ipass-details';
import { Observable } from 'rxjs';

@Component({
  selector: 'pwd-password-detail',
  templateUrl: './password-detail.component.html',
  styleUrls: ['./password-detail.component.css']
})
export class PasswordDetailComponent implements OnInit {
	title:string = 'Edit password details';
	isEdit : number = 1;
	editDetails : IPassDetails = null;
			
	constructor(private actRoute : ActivatedRoute) { 
	}

	ngOnInit() {
		let id = this.actRoute.snapshot.paramMap.get('id');
		console.log(id);
		
	}
	UpdatePwdDetails(pwdDetails : IPassDetails){
		
	}

}
