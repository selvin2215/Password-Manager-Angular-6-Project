import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { IPassDetails } from '../ipass-details';

import { ApiService } from '../db/api.service';

@Component({
  selector: 'pwd-add-update-form',
  templateUrl: './add-update-form.component.html',
  styleUrls: ['./add-update-form.component.css']
})
export class AddUpdateFormComponent implements OnInit {
	@Input('edit') isEdit : number;
	@Input('editDetails') editDetails : IPassDetails;
	@Output('SubmitDetails') sendDetails = new EventEmitter<any>();
	showPwd : boolean = false;
	pwdMeter : any[] = [
		{ class : "text-danger", text : 'Weak'},
		{ class : "text-warning", text : 'Medium'},
		{ class : "text-success", text : 'Strong'},
		{ class : "text-success", text : 'Very Strong'}
	];
	selPwdMeter : any = this.pwdMeter[0];

  	PasswordForm : FormGroup;
  	socialTypeArr : any[];
	//socialTypeArr : any[] = [{ group : 'Email', subGroup : [{name : 'Gmail', value : 'gmail', icon : 'fa fa-google'}, {name : 'Yahoo', value : 'yahoo', icon : 'fa fa-yahoo'}]}, { group : 'Social Media', subGroup : [{name : 'Facebook', value : 'facebook', icon : 'fa fa-facebook'}, {name : 'Instagram', value : 'instagram', icon : 'fa fa-instagram'}, {name : 'Quora', value : 'quora', icon : 'fa fa-quora'}, {name : 'Pinterest', value : 'pinterest', icon : 'fa fa-pinterest'}]}];

	constructor(private fb : FormBuilder, private apiService : ApiService) { 		
		
	}
	PasswordMeter() {
		let pwd = this.PasswordForm.get('password').value;
		let pwdLen = pwd.length, i = -1;
		let hasNumber = /\d/.test(pwd);
        let hasUpper = /[A-Z]/.test(pwd);
        let hasSpecialChar = /[$$!@%*#?&]/.test(pwd);
        if(pwdLen >= 6){
        	i++;
        }
        if(pwdLen >= 6 && hasUpper){
        	i++;
        }
        if(pwdLen >= 6 && hasNumber){
        	i++;
        }
        if(pwdLen >= 6 && hasSpecialChar){
        	i++;
        }
        this.selPwdMeter = i > -1 ? this.pwdMeter[i] : this.pwdMeter[0];
	}

	ngOnInit() {
		this.apiService.GetSocialTypeList()
			.subscribe((response) => {
				if(response.error == 0){
					this.socialTypeArr = response.data;
				}else{

				}
			}, error => {

			});
		this.PasswordForm = this.fb.group({
			socialType : [ (this.isEdit == 1) ? this.editDetails.socialType : 0, Validators.required],
			nickName : [ (this.isEdit == 1) ? this.editDetails.nickName : '', [Validators.required, Validators.minLength(5)]],
			userName : [ (this.isEdit == 1) ? this.editDetails.userName : '', [Validators.required]],
			password : [(this.isEdit == 1) ? this.editDetails.password : '', [Validators.required, Validators.minLength(6)]],
			description : [(this.isEdit == 1) ? this.editDetails.description : '']
		})
		if(this.isEdit == 1){
			this.PasswordMeter();
		}
	}

	GetSocialTypeClass() : any{
		return {
			'text-danger' : this.PasswordForm.get('socialType').touched && this.PasswordForm.get('socialType').invalid && this.PasswordForm.controls.socialType.hasError('required'), 
			'text-muted' : !(this.PasswordForm.get('socialType').touched && this.PasswordForm.get('socialType').invalid && this.PasswordForm.controls.socialType.hasError('required'))			
			}
	}
	GetPasswordClass() : any{
		return {
			'text-danger' : this.PasswordForm.get('password').touched && this.PasswordForm.get('password').invalid && ( this.PasswordForm.controls.password.hasError('required')  || this.PasswordForm.controls.password.hasError('minlength')), 
			'text-muted' : !(this.PasswordForm.get('password').touched && this.PasswordForm.get('password').invalid && ( this.PasswordForm.controls.password.hasError('required')  || this.PasswordForm.controls.password.hasError('minlength')))
			}
	}

	SavePasswordForm(){
		this.sendDetails.emit(this.PasswordForm.value);
	}

	TogglePassword(){
		this.showPwd = !this.showPwd;
	}

}
